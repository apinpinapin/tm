// Module
const fs = require('fs')

//Bot Settings
global.connect = true // True For Pairing // False For Qr
global.publicX = true // True For Public // False For Self
global.owner = ['6281231948641'] //Own Number
global.developer = "𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷" //Dev Name
global.botname = "𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷" //Bot Name
global.version = "Stable" //Version Bot

//Sticker Setiings
global.packname = "Sticker By" //Pack Name 
global.author = "𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷" // Author

//Social Media Settings
global.igram = "https://www.instagram.com/coreinpin/"
global.tgram = "https://t.me/apinmpfivee"

//Bug Name Settings
global.bak = {
Ios: " ⿻ᬃ𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷𝐥⃟⃟⿻ ",
Andro: "⩟⬦𪲁 𝐓͜͢𝐀͠𝐌̋͡𝐀̸̷̷̷͡𝐗͜͢𝐒 -", 
Crash: " ̶C̶r̶a̶s̶h̶U̶l̶t̶i̶m̶a̶̶t̶e ̶",
Freeze: "𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷",
Ui: "ℭ𝔯𝔴𝔰𝔥 𝔘𝔦 𝔖𝔶𝔰𝔱𝔢𝔪"
}

//System Bot Settings
global.prefa = ['','!','.',',','🐤','🗿'] // Prefix // Not Change

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})